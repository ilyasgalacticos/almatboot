package kz.bitlab.almatgroup.almatboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlmatbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlmatbootApplication.class, args);
	}

}
