package kz.bitlab.almatgroup.almatboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlmatbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
